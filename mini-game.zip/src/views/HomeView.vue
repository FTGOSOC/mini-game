<template>
  <div class="theGame">
    <div class="gameHeader">
        <div class="timer">
          <input type="number" v-model="timer">
        </div>
        <div class="startButton">
          <button class="startButton" @click="startTheGame" :disabled="gameInProgress">
            Почати
          </button>
        </div>
    </div>
    <div class="tilesWrapBg">
      <div class="tilesWrap">
        <div class="tiles">
          <div class="tileItem" v-for="(tile, index) in tiles" :key="index">
            <div
             class="tile" 
             :class="{inProgress: tile.inGameProgress, scoredByUser: tile.scoredByUser, scoredByPc:tile.scoredByPc}" 
             :ref="`tile${tile}`"
             @click="clickOnProgressItem(tile)"
             >
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="gameFooter">
      <span class="user">Гравець {{ userScore }}</span> / <span class="pc">{{ pcScore }} Комп'ютер</span>
    </div>
    <div class="resultsModalWrap" v-if="resultsModal" @click="closeModal">
      <div class="resultsModal">
        Рахунок
        <br>
        <span class="user">Гравець {{ userScore }}</span> / <span class="pc">{{ pcScore }} Комп'ютер</span>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  name: 'MiniGame',
  components: {
  },
  data() {
    return {
      userScore: 0,
      pcScore: 0,
      timer: 1000,
      tiles: Array.from({ length: 100 }, () => ({inGameProgress: false, scoredByUser: false, scoredByPc: false})),
      timeout: null,
      resultsModal: false,
      gameInProgress: false
    }
  },
  mounted() {
  },
  methods: {
    startTheGame() {
      if(this.userScore === 10 || this.pcScore === 10) {
        this.showResults()
        this.gameInProgress = false
        return
      }
      this.gameInProgress = true
      const validArray = this.tiles.filter(item => !(item.inGameProgress === true || item.scoredByUser === true || item.scoredByPc === true));
      const tileToChange = this.getRandomElement(validArray)
      tileToChange.inGameProgress = true
      this.timeout = setTimeout(() => {
        tileToChange.scoredByPc = true
        tileToChange.inGameProgress = false
        this.pcScore++
        this.startTheGame()
      }, this.timer) 
    },
    getRandomElement(array) {
      return array[Math.floor(Math.random() * array.length)];
    },
    clickOnProgressItem(item) {
      if (item.inGameProgress) {
        clearTimeout(this.timeout)
        item.scoredByUser = true
        item.inGameProgress = false
        this.userScore++
        this.startTheGame()
      }
    },
    showResults() {
      this.resultsModal = true
    },
    closeModal() {
      this.setDefaults()
    },
    setDefaults() {
      this.timer = 1000
      this.userScore = 0
      this.pcScore = 0
      this.tiles = Array.from({ length: 100 }, () => ({inGameProgress: false, scoredByUser: false, scoredByPc: false}))
      this.timeout = null
      this.resultsModal = false
    }
  }
}
</script>
<style lang="scss" scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
.theGame {
  font-family: Inter, sans-serif;
  min-height: 100vh; 
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 30px;
  background-color: #2E3044;
  text-transform: uppercase;
  font-weight: 700;
  .gameHeader{
    display: flex;
    justify-content: space-between;
    width: calc(600px - 17px * 2);
    background: #0C0D11;
    border-radius: 20px;
    padding: 15px 17px;
    box-shadow: 0px 24px 64px 0px #0000004D;
    .timer {
      input {
        background: #191919;
        color: #fff;
        outline: none;
        border: none;
        padding: 0 14px;
        border-radius: 10px;
        height: 40px;
        font-family: Inter, sans-serif;
        font-size: 18px;
        font-weight: 400;
        line-height: 25.6px;
        text-align: left;
        -webkit-appearance: textfield;
        -moz-appearance: textfield;
        appearance: textfield;
        &::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
      }
    }
    .startButton {
      button {
        cursor: pointer;
        background-color: #246BFD;
        outline: none;
        border: none;
        padding: 0 24px;
        font-family: Inter, sans-serif;
        font-size: 18px;
        font-weight: 800;
        line-height: 21.78px;
        color: #fff;
        height: 40px;
        border-radius: 10px;
      }
    }
  }
  .tilesWrapBg {
    height: 600px;
    width: 600px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 25px;
    background: linear-gradient(134.94deg, #86E8BD 0.66%, #90B9FB 12.65%, #B3A4FE 26.48%, #DDA9EF 43.28%, rgba(239, 178, 230, 0.3) 65.01%, rgba(239, 178, 230, 0) 98.59%);
    box-shadow: 0px 24px 64px 0px #0000004D;
    .tilesWrap {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 596px;
      width: 596px;
      background: #0C0D11;
      position: relative;
      border-radius: 25px;
      .tiles {
        display: flex;
        flex-wrap: wrap;
        height: 500px;
        width: 500px;
        .tileItem {
          width: 50px;
          height: 50px;
          display: flex;
          justify-content: center;
          align-items: center;
          .tile {
            background-color: #246BFD;
            height: 90%;
            width: 90%;
            border-radius: 2px;
            transition: all .1s ease;
            cursor: pointer;
            &:hover {
              transform: scale(1.08);
            }
          }
          .inProgress {
            background-color: #FFD861;
          }
          .scoredByUser {
            background-color: #73FFA1;
          }
          .scoredByPc {
            background-color: #E02C2C;
          }
        }
      }
    }
  }
  .gameFooter {
    width: 596px;
    padding: 10px;
    text-align: center;
  }
  .resultsModalWrap {
    position: absolute;
    height: 100vh;
    width: 100vw;
    left: 0;
    top: 0;
    background-color: rgba(255, 255, 255, .2);
    backdrop-filter: blur(2px);
    display: flex;
    justify-content: center;
    align-items: center;
    .resultsModal {
      background-color: #fff;
      border-radius: 20px;
      padding: 20px;
      text-align: center;
    }
  }
  .user {
      color: #73FFA1;
    }
    .pc {
      color: #E02C2C;
    }
}
</style>